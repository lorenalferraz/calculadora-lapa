export default {
  _widgetLabel: 'Filtrar e Baixar',
  addLayer: 'Adicionar Camada',
  featureServiceUrl: 'URL do Feature Service',
  instructions:
    'Digite um número na coluna "idea" para filtrar e dar zoom no polígono correspondente.',
  searchIdea: 'Pesquisar por número (idea)',
  filterAndZoom: 'Filtrar',
  clearFilter: 'Limpar Filtro',
  loading: 'Carregando...',
  layerLoaded: 'Camada carregada com sucesso!'
}
