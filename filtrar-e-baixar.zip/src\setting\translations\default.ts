export default {
  settings: 'Configurações',
  zoomToLayer: 'Zoom para camada',
  selectMapWidget: 'Selecionar widget de mapa'
}
